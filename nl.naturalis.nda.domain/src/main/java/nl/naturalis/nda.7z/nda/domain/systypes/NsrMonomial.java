package nl.naturalis.nda.domain.systypes;

public class NsrMonomial {

	private String rank;
	private String name;


	public String getRank()
	{
		return rank;
	}


	public void setRank(String rank)
	{
		this.rank = rank;
	}


	public String getName()
	{
		return name;
	}


	public void setName(String name)
	{
		this.name = name;
	}

}
