package nl.naturalis.nda.search;

import nl.naturalis.nda.domain.Occurrence;

public class OccurrenceSearchResultSet extends SearchResultSet<Occurrence>{

}
