package nl.naturalis.nda.search;

import nl.naturalis.nda.domain.Taxon;

public class TaxonSearchResultSet extends SearchResultSet<Taxon> {

}
